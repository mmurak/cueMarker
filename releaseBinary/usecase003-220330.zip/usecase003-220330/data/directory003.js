let directory = [
    ["Jabberwocky", "Jabberwocky.js"],
    ["あてなるもの", "Atenarumono.js"],
    ["成信の中将こそ", "Narinobu.js"],
];
